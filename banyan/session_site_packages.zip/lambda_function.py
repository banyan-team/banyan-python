import banyan as bn
import boto3
import gc
import json
from mpi4py import MPI
import numpy as np
import os
import psutil
import sys
import traceback

from utils_queues import (
    send_job_ready_message,
    send_end_message,
    send_session_ready_message,
    write_session_logs,
)


comm = MPI.COMM_WORLD
root = 0
rank = comm.Get_rank()
size = comm.Get_size()

client = boto3.client("sqs")

job_id = sys.argv[1]
session_id = sys.argv[2]
s3_bucket_name = sys.argv[3]

return_logs = sys.argv[4] == "True"
store_logs_in_s3 = sys.argv[5] == "True"
store_logs_on_cluster = sys.argv[6] == "True"
log_initialization = sys.argv[7] == "True"
debug_flag = sys.argv[8]
benchmark = sys.argv[11] == "True"
estimate_available_memory = sys.argv[12] == "True"
cluster_name = sys.argv[13]
num_workers = int(sys.argv[14])
region = sys.argv[10] if (sys.argv[10] != "none") else "us_west_2"


# Set current session
bn.set_session(session_id)
bn.session.sessions[session_id] = bn.Session(
    cluster_name, session_id, job_id, num_workers, 0
)


####################
# HELPER FUNCTIONS #
####################
def is_main_node():
    return comm.Get_rank() == 0


def is_debug_on():
    return debug_flag == "1"


def is_benchmark_on():
    return benchmark


def get_next_execution_request(delete=True):
    # Get next message from the execution queue
    queue = client.get_queue_url(
        QueueName=f"banyan_{bn.get_session().resource_id}_execution.fifo"
    )["QueueUrl"]
    m = client.receive_message(QueueUrl=queue, MaxNumberOfMessages=1)
    while ("Messages" not in m) or (len(m["Messages"]) < 1):
        m = client.receive_message(QueueUrl=queue)
    m = m["Messages"][0]
    if delete:
        client.delete_message(QueueUrl=queue, ReceiptHandle=m["ReceiptHandle"])
    return json.loads(m["Body"])


#############
# JOB READY #
#############

# Write a line to the job output file, so that we can keep track of the output
# that is specifically relevant to the job/sessions and not part of initialization
if is_main_node():
    with open(f"/home/ec2-user/banyan-output-for-job-{job_id}", "a") as f:
        f.write("Job output:\n")

# Compute free memory, if required
initial_memory_used = -1
if not estimate_available_memory:
    # TODO: Is rss the right thing?
    initial_memory_used = psutil.Process(os.getpid()).memory_info().rss
    comm.reduce(initial_memory_used, op=MPI.MAX, root=root)

if is_main_node():
    send_job_ready_message(bn.get_session().resource_id, initial_memory_used)


#######################
# MAIN EXECUTION LOOP #
#######################

# Each running instance of executor.jl corresponds to a running job. The job
# may or may not be allocated to a session. This loop will run infinitely as
# long as the job is still running. When there is no code to be executed or
# when the job is not allocatd to a session, then the main worker is listening
# on the execution queue and the other workers are waiting for information
# to be broadcasted from the main worker.

# SESSION_FAILURE: If any of the workers have an error, it is caught (in the
# catch block of the try-catch) and is gathered from all the workers. The main
# worker will (1) write a file to S3 and (2) send a SESSION_FAILURE message on
# the gather queue.

# JOB_FAILURE: If anything causes the executor to crash, the job will fail and
# the on_notok.sh job will get triggered. This will (1) write a file to S3 and
# (2) send a JOB_FAILURE message on the gather queue. See on_notok.sh for details.

# TODO: Try using a returned closure

# TODO: Maybe use let here to achieve the same goal of introducing local scope

for _ in range(1):
    data = {}  # Make this more restrictive than Any
    while True:
        print("", flush=True)  # TODO: perhaps remove this or move elsewhere
        error_str = np.array(list(""))
        evaluation_completed = False
        session_started = False
        session_ended = False
        try:
            # Get next message from execution queue if main node and broadcast
            code = None
            session_id = None
            if is_main_node():
                if is_debug_on():
                    print("Getting next execution request")
                req = get_next_execution_request()
                code = req["code"]
                session_id = req["session_id"]
                evaluation_completed = req["evaluation_end"]
                session_started = req["session_start"]
                session_ended = req["session_end"]
            code, session_id, session_started, session_ended = comm.bcast(
                (code, session_id, session_started, session_ended), root=root
            )
            if session_ended:
                # Reset state
                data = None
                data = {}
                gc.collect()
                continue
            if session_started:
                # Set the session ID
                bn.set_session(session_id)
                bn.session.sessions[session_id] = bn.Session(
                    cluster_name, session_id, job_id, num_workers, 0
                )
                # Reset state
                data = None
                data = {}
                gc.collect()
                if is_main_node():
                    # Create a log file for the session
                    open(
                        f"/home/ec2-user/banyan-log-for-session-{session_id}",
                        "w",
                    )
                    # Write session ID to info file
                    with open(
                        f"/home/ec2-user/job_{job_id}-curr-session-id", "w"
                    ) as f:
                        f.write(str(session_id))

            # Execute code
            if is_debug_on() and is_main_node():
                print(f"Executing code:\n{code}")
            exec(code)
            exec_code(data)
            if is_debug_on() and is_main_node():
                print("Finished executing code")

            # If the session just started, then this first code blob we received
            # was for using packages and including code files. So, let's send
            # a SESSION_READY message and also re-estimate the memory if requested
            if session_started:
                initial_memory_used = -1
                if not estimate_available_memory:
                    initial_memory_used = (
                        psutil.Process(os.getpid()).memory_info().rss
                    )
                    comm.reduce(initial_memory_used, op=MPI.MAX, root=root)
                if is_main_node():
                    # If return_logs, then write logs to session log file
                    if return_logs:
                        write_session_logs(
                            bn.get_session_id(),
                            job_id,
                            return_logs,
                            store_logs_in_s3,
                            store_logs_on_cluster,
                            log_initialization,
                        )
                    # Send session ready message
                    send_session_ready_message(
                        bn.get_session().resource_id,
                        session_id,
                        initial_memory_used,
                    )

        except:  # indicates error in the session, but the job doesn't need to end
            error_str_raw = traceback.format_exc()
            error_str = np.array(list(error_str_raw))
            error_str_raw_for_main_stuck = (
                f"Error on worker {rank+1} for session {session_id}:\n"
                + error_str_raw
            )
            if is_debug_on() and is_main_node():
                # Note that if thereis a barrier in the code and only one of
                # the non-main workers errors, the error wil get swallowed up
                # and never get printed here or below.
                print(error_str_raw_for_main_stuck)
                # We send these messages so that in the case that the main node is
                # stuck and can't send the error then at least we can send this.
            bn.send_to_client(-2, error_str_raw_for_main_stuck)

        # Get lengths of error messages for each worker
        error_str_lengths = np.array(comm.gather(len(error_str), root=root))

        # Determine whether session error occurred
        error_occurred = (
            any((l > 0 for l in error_str_lengths))
            if is_main_node()
            else False
        )

        error_occurred = comm.bcast(error_occurred, root=root)

        if error_occurred:
            # Reset state
            data = None
            data = {}
            gc.collect()

            # Make buffer for receiving all the error messages
            res = (
                np.empty(sum(error_str_lengths), dtype=error_str.dtype)
                if is_main_node()
                else None
            )

            comm.Gatherv(
                sendbuf=error_str, recvbuf=(res, error_str_lengths), root=root
            )

            # Print out the error message
            if is_main_node():
                error_strings = []  # String[]
                i = 0
                for l in error_str_lengths:
                    error_strings.append("".join(res[i : i + l - 1]))
                    i = i + l
                # For now, only print the first error message
                print(error_strings[0])

            if is_main_node():
                # if return_logs is false, then just return the error. otherwise
                # the whole of the logs, including the error message gets returned anyway
                error_str = error_strings[0] if not return_logs else None
                send_end_message(
                    bn.get_session_id(),
                    job_id,
                    "SESSION_FAILURE",
                    return_logs,
                    store_logs_in_s3,
                    store_logs_on_cluster,
                    log_initialization,
                    error_str=error_str,
                    is_debug_on=is_debug_on(),
                )
                # Write to S3 as well
                session_id = bn.get_session_id()
                with open(
                    f"/home/ec2-user/banyan-session-{session_id}-failed", "w"
                ) as f:
                    f.write(error_str)
                os.system(
                    f"aws s3 cp /home/ec2-user/banyan-session-{session_id}-failed s3://{s3_bucket_name}"
                )
                os.system(
                    f"rm /home/ec2-user/banyan-session-{session_id}-failed"
                )
                if is_debug_on():
                    print("Sent end message for SESSION_FAILURE")
        else:
            if is_main_node() and evaluation_completed:
                send_end_message(
                    bn.get_session_id(),
                    job_id,
                    "EVALUATION_END",
                    return_logs,
                    store_logs_in_s3,
                    store_logs_on_cluster,
                    log_initialization,
                    is_debug_on=is_debug_on(),
                )
                if is_debug_on():
                    print("Sent end message for EVALUATION_END")
