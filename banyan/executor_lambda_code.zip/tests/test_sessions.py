from banyan import start_session


def test_start_session():
    start_session()
