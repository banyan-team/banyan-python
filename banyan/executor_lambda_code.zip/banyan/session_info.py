class SessionInfo:
    pass