from typing import Any

# TODO: Store gather/scatter/shuffle queues


def send_to_client(data: Any):
    raise NotImplementedError()

def receive_to_client():
    raise NotImplementedError()